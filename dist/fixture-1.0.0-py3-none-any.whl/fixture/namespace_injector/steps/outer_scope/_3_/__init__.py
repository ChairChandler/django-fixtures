from .extractor import extract_args_names

__all__ = ['extract_args_names']
