from .pipe import create_wrapper

__all__ = ['create_wrapper']
