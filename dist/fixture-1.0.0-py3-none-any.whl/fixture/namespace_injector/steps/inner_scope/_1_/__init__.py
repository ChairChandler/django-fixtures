from .extractor import extract_fixtures

__all__ = ['extract_fixtures']
