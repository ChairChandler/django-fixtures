from .pipe import inject_fixtures

__all__ = ['inject_fixtures']
