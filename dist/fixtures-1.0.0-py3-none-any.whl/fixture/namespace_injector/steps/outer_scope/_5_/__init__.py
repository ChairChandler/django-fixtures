from .verify import verify_fixtures

__all__ = ['verify_fixtures']
