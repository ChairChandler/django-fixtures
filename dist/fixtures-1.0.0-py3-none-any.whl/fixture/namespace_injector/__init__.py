from .injector import use_fixture_namespace

__all__ = ['use_fixture_namespace']
