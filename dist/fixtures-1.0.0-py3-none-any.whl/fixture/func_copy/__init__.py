from .copy import func_copy

__all__ = ['func_copy']
